<?php
/**
 * Created by LianSen<zt15320@zongteng.net>.
 * User: LianSen
 * Date: 2020/7/2 0002
 */

namespace zt\test;
use Spatie\Activitylog\ActivityLogStatus;

class Test
{

    public static function say()
    {
        echo "众腾test v3\n";
       
    }


}
